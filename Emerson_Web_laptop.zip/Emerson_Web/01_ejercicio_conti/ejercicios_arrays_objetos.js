// Ejercicios arrays y objetos

// 1 ) Crea un array para albergar al menos 10 números enteros aleatorios entre 1 y 20, luego rellena el array con ellos.

let arrayNumeros = new Array(10);

for(let i = 0; i < 10; i++){

    arrayNumeros[i]=Math.floor(Math.random() * 20) + 1;
    
}


console.log(arrayNumeros)


// 2) Ahora trata de crear a partir de este array otros dos uno con los números pares y otro con los impares.


let arrayNumerosPares = arrayNumeros.filter(num => num % 2 === 0)
console.log(arrayNumerosPares)

let arrayNumerosimPares = arrayNumeros.filter(num => num % 2 > 0)

console.log(arrayNumerosimPares)


// 3)  Crea un array con al menos 10 elementos para guardar números enteros. Usa un método para obtener la suma de los números pares y la de los números impares.
// let NuarrayNumeros = new Array(10);

sumpare=0
sumimpa=0

arrayNumeros.forEach((num, index) => {

if (index % 2 === 0) {
    sumpare += num;


} else {
sumimpa += num;

}

})

console.log("Suma de los numeros pares: " + sumpare)

console.log("Suma de los numeros impa: " + sumimpa)






// 4) Tienes que crear un script que gestione una lista de la compra. Tienes esta lista de artículos:
let listaCompra = [
    {nombre : "patatas", comprado: true },
    {nombre : "cebollas", comprado: false },
    {nombre : "huevos", comprado: false },
    {nombre : "aceite", comprado: false },
    {nombre : "sal", comprado: true }
]
// Hay que crear una función que devuelva un array con los artículos que faltan por comprar (sólo los nombres). 

// 1er metodo
// ===============================================
faltaComprar_2=[]

let todofalse = listaCompra.filter(item => item.comprado===false)

console.log(todofalse)

todofalse.forEach((item, index) => {

faltaComprar_2.push(item.nombre)


})

console.log(faltaComprar_2)

// 2do metodo
// ===============================================

console.log(articulo_fal(listaCompra))

function articulo_fal(listaCompra)
{ 
faltaComprar=[]

listaCompra.forEach((item, index) => {

   if(item.comprado===false) {
    
    faltaComprar.push(item.nombre)
   }

})

return faltaComprar

}



// 5) Tienes una lista de objetos con los nombres de los miembros de una familia.
let familia = [
{nombre:'Victor', edad: 38},
{nombre:'Laura', edad: 40},
{nombre:'Clara', edad: 12} ,
{nombre:'Cesar', edad: 14}
]

// Necesitamos una función que devuelva dos objetos con el nombre y edad del miembro de mayor edad y del de menor edad.






familia.forEach((item, index) => {

    edadmenor=familia[0].edad 
    nombreMenor=familia[0].nombre 

    edadmayor=familia[0].edad 
    nombremayor=familia[0].nombre 

    //    edadmayor=item[index].edad

     if(item.edad < edadmenor){

         edadmenor=item.edad
         nombreMenor=item.nombre

     }

     if(item.edad > edadmayor){

        edadmayor=item.edad
        nombremayor=item.nombre

    }



})

let totalmenor={nombre:nombreMenor, edad:edadmenor}

let totalmayor={nombre:nombremayor, edad:edadmayor}

console.log(totalmenor)

console.log(totalmayor)